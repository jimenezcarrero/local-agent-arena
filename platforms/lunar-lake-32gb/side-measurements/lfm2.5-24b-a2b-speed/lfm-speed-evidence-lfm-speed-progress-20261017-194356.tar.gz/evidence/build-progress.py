import hashlib
import json
import pathlib
import shlex
import subprocess


root = pathlib.Path(__file__).resolve().parent
source = root / "llama-bench.cpp"
original_source = pathlib.Path.home() / "r1-t7-20261017-093233/llama.cpp"
commands = []


def link_command(build, target, destination, object_file=None):
    directory = build / "tools/llama-bench"
    link_file = directory / f"CMakeFiles/{target}.dir/link.txt"
    original = shlex.split(link_file.read_text())
    rewritten = []
    output_next = False
    for argument in original:
        if output_next:
            rewritten.append(str(destination))
            output_next = False
        elif argument == "-o":
            rewritten.append(argument)
            output_next = True
        elif argument.startswith("-Wl,--dependency-file="):
            continue
        elif argument.startswith("-Wl,-rpath,"):
            rewritten.append(f"-Wl,-rpath,{destination.parent}:{build / 'bin'}")
        elif not argument.startswith("-") and argument.endswith(".o"):
            rewritten.append(str(object_file or (directory / argument).resolve()))
        elif not argument.startswith("-") and ".so" in argument:
            library = pathlib.Path(argument).name
            if library == "libllama-bench-impl.so":
                rewritten.append(str(destination.parent / library))
            else:
                rewritten.append(str((directory / argument).resolve()))
        elif not argument.startswith("-") and argument.endswith(".a"):
            rewritten.append(str((directory / argument).resolve()))
        else:
            rewritten.append(argument)
    return rewritten


for backend, build_name in (("cpu", "build-host"), ("vulkan", "build-vulkan")):
    build = original_source / build_name
    output = root / backend
    binary_directory = output / "bin"
    binary_directory.mkdir(parents=True, exist_ok=True)
    object_file = output / "llama-bench.cpp.o"
    entries = json.loads((build / "compile_commands.json").read_text())
    entry = next(item for item in entries if item["file"].endswith("/tools/llama-bench/llama-bench.cpp"))
    compile_arguments = shlex.split(entry["command"])
    compile_arguments[compile_arguments.index("-o") + 1] = str(object_file)
    compile_arguments[compile_arguments.index("-c") + 1] = str(source)
    library = binary_directory / "libllama-bench-impl.so"
    executable = binary_directory / "llama-bench"
    build_commands = [
        compile_arguments,
        link_command(build, "llama-bench-impl", library, object_file),
        link_command(build, "llama-bench", executable),
    ]
    with (root / f"build-{backend}.log").open("w") as log:
        for command in build_commands:
            log.write(shlex.join(command) + "\n")
            log.flush()
            subprocess.run(command, cwd=entry["directory"], stdout=log, stderr=subprocess.STDOUT, check=True)
            commands.append(command)
    for dependency in (build / "bin").glob("*.so*"):
        destination = binary_directory / dependency.name
        if destination.name != library.name and not destination.is_symlink():
            destination.symlink_to(dependency)
    print(f"Built instrumented {backend} benchmark", flush=True)

(root / "build-commands.json").write_text(json.dumps(commands, indent=2) + "\n")
records = []
for artifact in [source, pathlib.Path(__file__).resolve(), root / "build-commands.json", root / "lfm-speed-progress.sh", root / "monitor.py", root / "token-progress.patch", root / "README.md", *sorted(root.glob("*/bin/llama-bench")), *sorted(root.glob("*/bin/libllama-bench-impl.so"))]:
    records.append(f"{hashlib.sha256(artifact.read_bytes()).hexdigest()}  {artifact}\n")
(root / "instrumentation.sha256").write_text("".join(records))
