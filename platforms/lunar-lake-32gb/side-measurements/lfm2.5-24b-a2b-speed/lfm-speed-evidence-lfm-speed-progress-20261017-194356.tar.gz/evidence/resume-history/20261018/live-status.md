Updated: 2026-10-18T01:01:04+02:00
Commands: 3/12 done; 0 recorded failures
Command counts are not a time-based percentage.
Current: M2-vulkan-cold32k
Phase: llama-bench: benchmark 1/1: prompt run 3/3
Tokens: 32768/32768 (100.0%, completed); elapsed 205.1s; 159.73 tok/s; rough phase ETA 0.0 min
Last output: 0.0s ago; silence alone does not prove a stall.
Benchmark CPU: None% (400% means four cores)
Benchmark RSS: 0.0 MiB; swap: 0.0 MiB
Available RAM: 17.17 GiB; disk free: 7.41 GiB
Unused RAM: 2.77 GiB; file cache: 16.12 GiB
Graphics memory: active 0.03 GiB; reclaimable 9.84 GiB
CPU temperatures: {'TCPU': 55.05, 'x86_pkg_temp': 56.0}
Resource pressure (10s averages): {'cpu_some_avg10': 0.0, 'cpu_full_avg10': 0.0, 'memory_some_avg10': 0.0, 'memory_full_avg10': 0.0, 'io_some_avg10': 0.0, 'io_full_avg10': 0.0}
Finished: False; stop: STOP: MemAvailable 18008604 kB < 18 GiB before M2 vulkan depth: close apps by hand, then resume with W=/home/juan/lfm-speed-progress-20261017-194356

| Command | State |
|---|---|
| M2-cpu-cold32k | done |
| M2-cpu-depth | done |
| M2-vulkan-cold32k | done |
| M2-vulkan-depth | waiting |
| Q4KM-cpu-cold32k | waiting |
| Q4KM-cpu-depth | waiting |
| Q4KM-vulkan-cold32k | waiting |
| Q4KM-vulkan-depth | waiting |
| REF-cpu-cold32k | waiting |
| REF-cpu-depth | waiting |
| REF-vulkan-cold32k | waiting |
| REF-vulkan-depth | waiting |
