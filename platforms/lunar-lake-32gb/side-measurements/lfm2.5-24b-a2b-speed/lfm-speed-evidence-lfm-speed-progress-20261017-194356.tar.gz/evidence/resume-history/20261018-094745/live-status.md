Updated: 2026-10-18T08:37:45+02:00
Commands: 4/12 done; 0 recorded failures
Command counts are not a time-based percentage.
Current: M2-vulkan-depth
Phase: llama-bench: benchmark 6/6: generation run 3/3
Tokens: 128/128 (100.0%, completed); elapsed 4.8s; 26.77 tok/s; rough phase ETA 0.0 min
Last output: 0.0s ago; silence alone does not prove a stall.
Benchmark CPU: None% (400% means four cores)
Benchmark RSS: 0.0 MiB; swap: 0.0 MiB
Available RAM: 17.74 GiB; disk free: 7.41 GiB
Unused RAM: 1.71 GiB; file cache: 17.50 GiB
Graphics memory: active 0.92 GiB; reclaimable 8.69 GiB
CPU temperatures: {'TCPU': 58.05, 'x86_pkg_temp': 59.0}
Resource pressure (10s averages): {'cpu_some_avg10': 0.0, 'cpu_full_avg10': 0.0, 'memory_some_avg10': 0.0, 'memory_full_avg10': 0.0, 'io_some_avg10': 0.0, 'io_full_avg10': 0.0}
Finished: False; stop: STOP: MemAvailable 18601832 kB < 18 GiB before Q4KM cpu cold32k: close apps by hand, then resume with W=/home/juan/lfm-speed-progress-20261017-194356

| Command | State |
|---|---|
| M2-cpu-cold32k | done |
| M2-cpu-depth | done |
| M2-vulkan-cold32k | done |
| M2-vulkan-depth | done |
| Q4KM-cpu-cold32k | waiting |
| Q4KM-cpu-depth | waiting |
| Q4KM-vulkan-cold32k | waiting |
| Q4KM-vulkan-depth | waiting |
| REF-cpu-cold32k | waiting |
| REF-cpu-depth | waiting |
| REF-vulkan-cold32k | waiting |
| REF-vulkan-depth | waiting |
