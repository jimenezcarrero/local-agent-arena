Updated: 2026-10-18T15:13:46+02:00
Commands: 7/12 done; 0 recorded failures
Command counts are not a time-based percentage.
Current: Q4KM-vulkan-cold32k
Phase: llama-bench: benchmark 1/1: prompt run 3/3
Tokens: 32768/32768 (100.0%, completed); elapsed 200.9s; 163.12 tok/s; rough phase ETA 0.0 min
Last output: 0.0s ago; silence alone does not prove a stall.
Benchmark CPU: None% (400% means four cores)
Benchmark RSS: 0.0 MiB; swap: 0.0 MiB
Available RAM: 13.46 GiB; disk free: 7.41 GiB
Unused RAM: 1.15 GiB; file cache: 13.77 GiB
Graphics memory: active 0.34 GiB; reclaimable 14.35 GiB
CPU temperatures: {'TCPU': 58.05, 'x86_pkg_temp': 59.0}
Resource pressure (10s averages): {'cpu_some_avg10': 0.0, 'cpu_full_avg10': 0.0, 'memory_some_avg10': 0.0, 'memory_full_avg10': 0.0, 'io_some_avg10': 0.0, 'io_full_avg10': 0.0}
Finished: False; stop: STOP: MemAvailable 14112596 kB < 18 GiB before Q4KM vulkan depth: close apps by hand, then resume with W=/home/juan/lfm-speed-progress-20261017-194356

| Command | State |
|---|---|
| M2-cpu-cold32k | done |
| M2-cpu-depth | done |
| M2-vulkan-cold32k | done |
| M2-vulkan-depth | done |
| Q4KM-cpu-cold32k | done |
| Q4KM-cpu-depth | done |
| Q4KM-vulkan-cold32k | done |
| Q4KM-vulkan-depth | waiting |
| REF-cpu-cold32k | waiting |
| REF-cpu-depth | waiting |
| REF-vulkan-cold32k | waiting |
| REF-vulkan-depth | waiting |
