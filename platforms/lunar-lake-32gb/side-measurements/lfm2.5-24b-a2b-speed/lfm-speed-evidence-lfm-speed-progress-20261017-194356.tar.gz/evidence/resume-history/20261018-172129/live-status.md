Updated: 2026-10-18T17:15:23+02:00
Commands: 8/12 done; 0 recorded failures
Command counts are not a time-based percentage.
Current: Q4KM-vulkan-depth
Phase: llama-bench: benchmark 6/6: generation run 3/3
Tokens: 128/128 (100.0%, completed); elapsed 5.4s; 23.57 tok/s; rough phase ETA 0.0 min
Last output: 0.1s ago; silence alone does not prove a stall.
Benchmark CPU: None% (400% means four cores)
Benchmark RSS: 0.0 MiB; swap: 0.0 MiB
Available RAM: 9.62 GiB; disk free: 8.02 GiB
Unused RAM: 1.79 GiB; file cache: 9.56 GiB
Graphics memory: active 0.74 GiB; reclaimable 14.52 GiB
CPU temperatures: {'TCPU': 53.05, 'x86_pkg_temp': 54.0}
Resource pressure (10s averages): {'cpu_some_avg10': 0.07, 'cpu_full_avg10': 0.0, 'memory_some_avg10': 0.0, 'memory_full_avg10': 0.0, 'io_some_avg10': 0.04, 'io_full_avg10': 0.04}
Finished: False; stop: STOP: MemAvailable 10084884 kB < 26 GiB before REF cpu cold32k: close apps by hand, then resume with W=/home/juan/lfm-speed-progress-20261017-194356

| Command | State |
|---|---|
| M2-cpu-cold32k | done |
| M2-cpu-depth | done |
| M2-vulkan-cold32k | done |
| M2-vulkan-depth | done |
| Q4KM-cpu-cold32k | done |
| Q4KM-cpu-depth | done |
| Q4KM-vulkan-cold32k | done |
| Q4KM-vulkan-depth | done |
| REF-cpu-cold32k | waiting |
| REF-cpu-depth | waiting |
| REF-vulkan-cold32k | waiting |
| REF-vulkan-depth | waiting |
