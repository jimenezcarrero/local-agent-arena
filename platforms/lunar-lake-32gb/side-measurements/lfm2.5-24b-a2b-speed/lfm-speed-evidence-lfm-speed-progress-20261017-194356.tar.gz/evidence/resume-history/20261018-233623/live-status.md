Updated: 2026-10-18T22:59:42+02:00
Commands: 10/12 done; 1 recorded failures
Command counts are not a time-based percentage.
Current: REF-vulkan-cold32k
Phase: llama-bench: benchmark 1/1: starting
Last output: 0.2s ago; silence alone does not prove a stall.
Benchmark CPU: None% (400% means four cores)
Benchmark RSS: 0.0 MiB; swap: 0.0 MiB
Available RAM: 14.41 GiB; disk free: 8.00 GiB
Unused RAM: 10.82 GiB; file cache: 5.33 GiB
Graphics memory: active 0.04 GiB; reclaimable 13.17 GiB
CPU temperatures: {'TCPU': 58.05, 'x86_pkg_temp': 59.0}
Resource pressure (10s averages): {'cpu_some_avg10': 0.0, 'cpu_full_avg10': 0.0, 'memory_some_avg10': 4.76, 'memory_full_avg10': 4.76, 'io_some_avg10': 0.0, 'io_full_avg10': 0.0}
Finished: False; stop: STOP: MemAvailable 14801788 kB < 26 GiB before REF vulkan depth: close apps by hand, then resume with W=/home/juan/lfm-speed-progress-20261017-194356

| Command | State |
|---|---|
| M2-cpu-cold32k | done |
| M2-cpu-depth | done |
| M2-vulkan-cold32k | done |
| M2-vulkan-depth | done |
| Q4KM-cpu-cold32k | done |
| Q4KM-cpu-depth | done |
| Q4KM-vulkan-cold32k | done |
| Q4KM-vulkan-depth | done |
| REF-cpu-cold32k | done |
| REF-cpu-depth | done |
| REF-vulkan-cold32k | failed |
| REF-vulkan-depth | waiting |
