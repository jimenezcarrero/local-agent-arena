# Resume after owner-performed cache cleanup

The owner reported running `sudo sh -c 'sync; echo 3 > /proc/sys/vm/drop_caches'` while the benchmark was stopped. At 2026-10-18T08:29:42+02:00, MemAvailable was 28,599,316 kB and GPUReclaim was 496 kB, compared with roughly 17.1 GiB available RAM and 9.8 GiB reclaimable graphics memory before cleanup. The cleanup was outside the timed benchmarks; it did not change benchmark flags, memory guards or model files.

Resume uses the same work directory, `/home/juan/lfm-speed-progress-20261017-194356`, and preserves the three completed commands: M2 CPU cold32k, M2 CPU depth, and M2 Vulkan cold32k. Completed benchmark files are checksummed before resume and checked afterward. A pre-resume backup of the original evidence and console is retained.

The monitor received a display-only fix: it now interprets STOP, current phase and finished status from the latest invocation's status-log section, so a previous memory STOP is not shown as a new active stop. No C++ instrumentation, executable, inference setting or memory threshold was changed. The previous monitor, manifest and host record are saved in `evidence/resume-history/20261018/` before the runner refreshes them.
