import argparse
import datetime
import json
import os
import pathlib
import re
import signal
import threading
import time


TOKEN_PROGRESS = re.compile(
    r"llama-bench: (?P<phase>prefill|generation) tokens (?P<tokens>\d+)/(?P<total>\d+) "
    r"\((?P<percent>[\d.]+)%, (?P<state>submitted|completed)\) "
    r"elapsed=(?P<elapsed>[\d.]+)s rate=(?P<rate>[\d.]+) tok/s eta~(?P<eta>-?[\d.]+)s"
)


def tail(path):
    try:
        with path.open("rb") as stream:
            stream.seek(0, 2)
            stream.seek(max(0, stream.tell() - 65536))
            return stream.read().decode("utf-8", errors="replace")
    except OSError:
        return ""


def process_status(root):
    executables = {str(root / backend / "bin/llama-bench") for backend in ("cpu", "vulkan")}
    for process in pathlib.Path("/proc").iterdir():
        if not process.name.isdigit():
            continue
        try:
            if os.readlink(process / "exe") not in executables:
                continue
            fields = (process / "stat").read_text().rsplit(") ", 1)[1].split()
            status = {}
            for line in (process / "status").read_text().splitlines():
                if line.startswith(("VmRSS:", "RssAnon:", "RssFile:", "VmSwap:", "Threads:")):
                    status[line.split(":")[0]] = int(line.split()[1])
            status.update(
                pid=int(process.name),
                state=fields[0],
                cpu_seconds=(int(fields[11]) + int(fields[12])) / os.sysconf("SC_CLK_TCK"),
                minor_faults=int(fields[7]),
                major_faults=int(fields[9]),
            )
            return status
        except (OSError, ValueError, IndexError):
            continue
    return {}


def collect(work, root, previous=None):
    evidence = work / "evidence"
    status = tail(evidence / "status.txt")
    session_start = status.rfind("=== lfm-speed ")
    if session_start >= 0:
        status = status[session_start:]
    current = None
    for line in status.splitlines():
        match = re.match(r"run (M2|Q4KM|REF) (cpu|vulkan) (cold32k|depth) \(", line)
        if match:
            current = "-".join(match.groups())
    cases = {}
    for model in ("M2", "Q4KM", "REF"):
        for backend in ("cpu", "vulkan"):
            for test in ("cold32k", "depth"):
                case = f"{model}-{backend}-{test}"
                output = evidence / f"bench-{case}.txt"
                cases[case] = "done" if pathlib.Path(str(output) + ".done").exists() else "failed" if pathlib.Path(str(output) + ".failed").exists() else "running" if case == current else "waiting"
    progress = None
    phase = None
    idle = None
    if current:
        output = evidence / f"bench-{current}.txt"
        for line in tail(output).splitlines():
            if re.match(r"llama-bench: benchmark \d+/\d+:", line):
                phase = line
                progress = None
            match = TOKEN_PROGRESS.search(line)
            if match:
                progress = match.groupdict()
        try:
            idle = round(max(0, time.time() - output.stat().st_mtime), 1)
        except OSError:
            pass
    memory = {}
    for line in pathlib.Path("/proc/meminfo").read_text().splitlines():
        if line.startswith(("MemTotal:", "MemAvailable:", "MemFree:", "Cached:", "SwapTotal:", "SwapFree:", "GPUActive:", "GPUReclaim:")):
            memory[line.split(":")[0]] = int(line.split()[1])
    pressure = {}
    for resource in ("cpu", "memory", "io"):
        for line in pathlib.Path(f"/proc/pressure/{resource}").read_text().splitlines():
            values = line.split()
            pressure[f"{resource}_{values[0]}_avg10"] = float(values[1].split("=")[1])
    temperature = {}
    for sensor in pathlib.Path("/sys/class/thermal").glob("thermal_zone*"):
        try:
            name = (sensor / "type").read_text().strip()
            if name in ("x86_pkg_temp", "TCPU"):
                temperature[name] = int((sensor / "temp").read_text()) / 1000
        except (OSError, ValueError):
            pass
    clock_mhz = []
    for clock in pathlib.Path("/sys/devices/system/cpu").glob("cpu[0-9]*/cpufreq/scaling_cur_freq"):
        try:
            clock_mhz.append(round(int(clock.read_text()) / 1000))
        except (OSError, ValueError):
            pass
    process = process_status(root)
    now = time.monotonic()
    cpu_percent = None
    if previous and process and previous["process"].get("pid") == process["pid"]:
        cpu_percent = round(100 * (process["cpu_seconds"] - previous["process"]["cpu_seconds"]) / (now - previous["monotonic"]), 1)
    filesystem = os.statvfs(work)
    return dict(
        timestamp=datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
        monotonic=now,
        cases=cases,
        current=current,
        phase=phase,
        tokens=progress,
        log_idle_seconds=idle,
        process=process,
        cpu_percent=cpu_percent,
        memory_kib=memory,
        disk_free_gib=round(filesystem.f_bavail * filesystem.f_frsize / 1024**3, 2),
        temperature_c=temperature,
        clock_mhz=clock_mhz,
        pressure=pressure,
        finished="=== finished" in status,
        stop_line=next((line for line in reversed(status.splitlines()) if line.startswith("STOP:")), None),
    )


def write_status(work, snapshot):
    cases = snapshot["cases"]
    lines = [
        f"Updated: {snapshot['timestamp']}",
        f"Commands: {list(cases.values()).count('done')}/12 done; {list(cases.values()).count('failed')} recorded failures",
        "Command counts are not a time-based percentage.",
        f"Current: {snapshot['current'] or 'not started'}",
        f"Phase: {snapshot['phase'] or 'waiting for a phase message'}",
    ]
    progress = snapshot["tokens"]
    if progress:
        estimate = f"{float(progress['eta']) / 60:.1f} min" if float(progress["eta"]) >= 0 else "unknown"
        lines.append(f"Tokens: {progress['tokens']}/{progress['total']} ({progress['percent']}%, {progress['state']}); elapsed {progress['elapsed']}s; {progress['rate']} tok/s; rough phase ETA {estimate}")
    lines.extend([
        f"Last output: {snapshot['log_idle_seconds']}s ago; silence alone does not prove a stall.",
        f"Benchmark CPU: {snapshot['cpu_percent']}% (400% means four cores)",
        f"Benchmark RSS: {snapshot['process'].get('VmRSS', 0) / 1024:.1f} MiB; swap: {snapshot['process'].get('VmSwap', 0) / 1024:.1f} MiB",
        f"Available RAM: {snapshot['memory_kib']['MemAvailable'] / 1024**2:.2f} GiB; disk free: {snapshot['disk_free_gib']:.2f} GiB",
        f"Unused RAM: {snapshot['memory_kib']['MemFree'] / 1024**2:.2f} GiB; file cache: {snapshot['memory_kib']['Cached'] / 1024**2:.2f} GiB",
        f"Graphics memory: active {snapshot['memory_kib'].get('GPUActive', 0) / 1024**2:.2f} GiB; reclaimable {snapshot['memory_kib'].get('GPUReclaim', 0) / 1024**2:.2f} GiB",
        f"CPU temperatures: {snapshot['temperature_c']}",
        f"Resource pressure (10s averages): {snapshot['pressure']}",
        f"Finished: {snapshot['finished']}; stop: {snapshot['stop_line']}",
        "",
        "| Command | State |",
        "|---|---|",
        *[f"| {case} | {state} |" for case, state in cases.items()],
    ])
    for filename, contents in (("live-status.md", "\n".join(lines) + "\n"), ("live-status.json", json.dumps(snapshot, indent=2) + "\n")):
        destination = work / filename
        temporary = destination.with_suffix(destination.suffix + ".tmp")
        temporary.write_text(contents)
        temporary.replace(destination)
    with (work / "evidence/telemetry.jsonl").open("a") as stream:
        stream.write(json.dumps(snapshot) + "\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("work", type=pathlib.Path)
    parser.add_argument("--root", type=pathlib.Path, default=pathlib.Path(__file__).resolve().parent)
    parser.add_argument("--interval", type=float, default=10)
    parser.add_argument("--once", action="store_true")
    args = parser.parse_args()
    stop = threading.Event()
    for number in (signal.SIGTERM, signal.SIGINT):
        signal.signal(number, lambda *_: stop.set())
    previous = None
    while True:
        snapshot = collect(args.work, args.root, previous)
        write_status(args.work, snapshot)
        previous = snapshot
        if args.once:
            break
        if stop.wait(args.interval):
            write_status(args.work, collect(args.work, args.root, previous))
            break


if __name__ == "__main__":
    main()
