#!/bin/bash
# R2 load 1, attempt 3 (attempt 1: probe not executable; attempt 2: no libcdsprpc.so link in the package; neither reached the NPU) (k5-r2/README.txt section 2), exactly the manifest's command; P is the extracted package's inner directory.
T=/home/arduino/Repositories/laa-npu-dev/platforms/ventuno-q-16gb/npu-dev/tools
P=$HOME/npu-dev/pkg-unpatched-af0579c7/pkg-unpatched-af0579c7
M=$HOME/npu-dev/models/LFM2.5-24B-A2B-M2-Q2_K-af0579c7.gguf
O=$HOME/bench-runs/npu-dev/r2/load1-npu-r-prime-a3
L=$HOME/bench-runs/npu-dev/r2/load1-a3-wrapper-console.txt
cd ~/bench-runs || exit 1
setsid nohup bash $T/npu_dev_run.sh --stage r2 --run load1-npu-r-prime-a3 --timeout 1800 --expect-dsp yes --floor-mib 1536 --stall-s 120 \
 --declared-peak-mib 2594.0,2501.5,2491.7,2236.7 --declared-board-mib 10565.2 \
 --hash $M --hash $P/bin/llama-server --hash $P/lib/libllama-server-impl.so --hash $P/lib/libggml-htp-v75.so \
 --env GGML_HEXAGON_NHMX=1 --env LD_LIBRARY_PATH=$P/lib --env ADSP_LIBRARY_PATH=$P/lib --env GGML_HEXAGON_DEVICES=HTP0:0,HTP0:1,HTP0:2,HTP0:3 \
 --env GGML_HEXAGON_VERBOSE=1 --env GGML_SCHED_DEBUG=2 -- \
 /bin/bash $T/r2_load_probe.sh $O/probe 18090 900 -- $P/bin/llama-server -m $M -c 16384 -np 1 -fa on -b 2048 -ub 512 -ngl 999 \
 --device HTP0:0,HTP0:1,HTP0:2,HTP0:3 -ts 11,10,10,10 -ot 'token_embd\.weight=CPU' --cache-ram 0 -lv 5 --no-webui > $L 2>&1 < /dev/null &
echo "R2 load 1 started in the background (pid $!); console: $L"
