#!/bin/bash
# B1c (9B) load (b1-bonsai/README.txt stage B1c, revised 6d5b964/3a1e98d/0a9e2d7, merged): two NPU sessions, exactly the
# README's command; the owner's approval 2026-10-21 ("You have my approval for diagnostic and the 9B load"). Tools from
# the main checkout (npu-dev identical to origin/main).
T=/home/arduino/Repositories/laa-npu-dev/platforms/ventuno-q-16gb/npu-dev/tools
P=$HOME/npu-dev/pkg-unpatched-ff5a2337/pkg-unpatched-ff5a2337
M=$HOME/npu-dev/b1/models/Ternary-Bonsai-2-9B-Q2_0.gguf
O=$HOME/bench-runs/npu-dev/b1/load1-s2
L=$HOME/bench-runs/npu-dev/b1/load1-s2-wrapper-console.txt
[ -e $O ] && { echo "$O exists"; exit 1; }
for f in llama-server llama-perplexity llama-bench; do [ "$(cat $HOME/npu-dev/farf/$f.farf)" = 0x1f ] || { echo "$f.farf is not 0x1f"; exit 1; }; done
echo "1f884aa56aacd2bbbb2e4b7abaead2b1102b74a9c75a23fc33dab916813a384d  $M" | sha256sum -c - || exit 1
python3 $HOME/v0/pkg_identity.py check $HOME/v0/pkg-identity-ff5a2337.txt $P | tail -1 | grep -q 'PASS' || { echo "package identity FAILED"; exit 1; }
bash $HOME/npu-dev/b1/b1c-9b/identity.sh $HOME/bench-runs/npu-dev/b1/9b-load1-identity-before.txt > /dev/null
cd ~/bench-runs || exit 1
setsid nohup bash $T/npu_dev_run.sh --stage b1 --run load1-s2 --timeout 1800 --expect-dsp yes --floor-mib 1536 --stall-s 120 \
 --declared-peak-mib 1650,1650 --declared-board-mib 4200 \
 --hash $M --hash $P/bin/llama-server --hash $P/lib/libllama-server-impl.so --hash $P/lib/libggml-htp-v75.so \
 --env GGML_HEXAGON_NHMX=1 --env LD_LIBRARY_PATH=$P/lib --env "ADSP_LIBRARY_PATH=$HOME/npu-dev/farf;$P/lib" \
 --env GGML_HEXAGON_DEVICES=HTP0:0,HTP0:1 --env GGML_HEXAGON_VERBOSE=1 --env GGML_SCHED_DEBUG=2 -- \
 /bin/bash $T/r2_load_probe.sh $O/probe 18090 900 -- $P/bin/llama-server -m $M -c 16384 -np 1 -fa on \
 -b 2048 -ub 512 -ngl 999 --device HTP0:0,HTP0:1 -ts 18,15 -ot 'token_embd\.weight=CPU' --cache-ram 0 \
 -lv 5 --no-webui > $L 2>&1 < /dev/null &
echo "B1c (9B) load started in the background (pid $!); console: $L"
