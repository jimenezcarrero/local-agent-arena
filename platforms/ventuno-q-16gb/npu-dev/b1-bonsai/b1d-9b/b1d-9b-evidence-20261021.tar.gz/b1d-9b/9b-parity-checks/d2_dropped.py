#!/usr/bin/env python3
"""d2 (b1d-9b/SPEC.txt c): every node in an extra CPU split (not split #0) of the last load phase, with each of its
supports-op queries in that graph's own block; OK only if every such node has at least one query, every query has a
zero-element result shape and ends 'no'. Usage: d2_dropped.py <log>"""
import re, sys
P = re.compile(r"\d+\.\d{2}\.\d{3}\.\d{3} [IWED] ")
L = P.sub("", open(sys.argv[1], errors="replace").read()).splitlines()
st = [i for i, l in enumerate(L) if "assigned to device" in l and (i == 0 or "assigned to device" not in L[i - 1])][-1]
g, blk, cur, sp, bad, n = 0, [], [], None, 0, 0
for l in L[st:]:
    if l.startswith("ggml-hex:") and "supports-op" in l: blk.append(l); continue
    m = re.match(r"^## SPLIT #(\d+): (\S+)", l)
    if m:
        if m.group(1) == "0": g += 1; cur, blk = blk, []
        sp = (int(m.group(1)), m.group(2)); continue
    if l.startswith("node #") and sp and sp[1] == "CPU" and sp[0] != 0:
        op = re.search(r"\(\s*([A-Z_0-9]+)\)", l).group(1); name = l.split("):", 1)[1][:22].strip()
        q = [x.split("|") for x in cur if f"supports-op {op}|" in x and x.split("|")[1].split(" -> ")[-1].strip()[:20] == name[:20]]
        res = [(f[2].split(" -> ")[-1].strip(), f[-1].strip()) for f in q]
        ok = bool(res) and all(v == "no" and any(d.strip() == "0" for d in s.split(":")) for s, v in res)
        n += 1; bad += not ok
        print(f"{'ok ' if ok else 'BAD'} graph {g} split #{sp[0]} {op} {name}: {len(res)} queries " + ", ".join(sorted(set(f'{s} {v}' for s, v in res))))
print(f"RESULT {'OK' if not bad else 'FAIL'}: {n} dropped node(s), {bad} not proved zero-extent")
sys.exit(1 if bad else 0)
