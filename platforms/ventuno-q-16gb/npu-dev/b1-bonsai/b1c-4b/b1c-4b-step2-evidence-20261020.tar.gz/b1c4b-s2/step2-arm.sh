#!/bin/bash
# B1c-4B Step 2 (SPEC.txt revision 4, after Codex READY): one parity arm under the wrapper. step2-arm.sh 2a|2b|2c
# 2a NPU -ub 512, 2b NPU -ub 384, 2c CPU-pkg -ub 512. Checks the FARF files and REF before launching.
set -uo pipefail
ARM=$1
T=/home/arduino/Repositories/laa-npu-dev/platforms/ventuno-q-16gb/npu-dev/tools
P=$HOME/npu-dev/pkg-unpatched-ff5a2337/pkg-unpatched-ff5a2337
M=$HOME/npu-dev/b1/models/Ternary-Bonsai-2-4B-Q2_0.gguf
REF=$HOME/npu-dev/b1/b1c-4b/step0/cpu-ref.kld
FS=7acc31cde8878ed69e7db525b71c42440f49d29972de44d6c0653564a613e645
for n in llama-server llama-perplexity llama-bench; do
  echo "$FS  $HOME/npu-dev/farf/$n.farf" | sha256sum -c --quiet - || { echo "farf $n mismatch"; exit 1; }
done
echo "7fd9868c39deca75adb50e529ae8b005519c75eafa31df3c074aed76cece4444  $REF" | sha256sum -c --quiet - || { echo "REF mismatch"; exit 1; }
case $ARM in
  2a) UB=512; EXP=yes; DEV=(-ngl 999 --device HTP0:0); PEAK=(--declared-peak-mib 1950);;
  2b) UB=384; EXP=yes; DEV=(-ngl 999 --device HTP0:0); PEAK=(--declared-peak-mib 1950);;
  2c) UB=512; EXP=no;  DEV=(-ngl 0 --device none);       PEAK=();;
  *) echo "arm 2a|2b|2c"; exit 2;;
esac
L=$HOME/bench-runs/npu-dev/b1/4b-parity-$ARM-wrapper-console.txt
cd ~/bench-runs || exit 1
setsid nohup bash $T/npu_dev_run.sh --stage b1 --run 4b-parity-$ARM --timeout 5400 --expect-dsp $EXP --floor-mib 1536 --stall-s 120 \
 "${PEAK[@]}" --declared-board-mib 4500 \
 --hash $M --hash $P/bin/llama-perplexity --hash $P/lib/libllama-perplexity-impl.so --hash $P/lib/libllama.so.0.7.0 \
 --hash $P/lib/libggml-base.so.0.27.0 --hash $P/lib/libggml-hexagon.so.0.27.0 --hash $P/lib/libggml-htp-v75.so \
 --env GGML_HEXAGON_NHMX=1 --env LD_LIBRARY_PATH=$P/lib --env "ADSP_LIBRARY_PATH=$HOME/npu-dev/farf;$P/lib" \
 --env GGML_HEXAGON_DEVICES=HTP0:0 --env GGML_HEXAGON_VERBOSE=1 --env GGML_SCHED_DEBUG=2 -- \
 $P/bin/llama-perplexity -m $M --kl-divergence-base $REF --kl-divergence -c 1024 -b 1024 -ub $UB \
 --chunks 10 -t 8 -fa on -lv 5 "${DEV[@]}" > $L 2>&1 < /dev/null &
echo "B1c-4B Step 2 arm $ARM started (pid $!); console: $L"
