#!/bin/bash
# Attempt 3 (spec rev 3): ~/v0/farf first on ADSP_LIBRARY_PATH (DSP logging); owner go 2026-10-20 ("Yes to both"), after Codex READY on rev 3.
# B1c-4B Step 1 (b1-bonsai/b1c-4b/SPEC.txt, merged fb9b918): one NPU session load of Ternary-Bonsai-2-4B Q2_0, exactly the
# spec's command; the owner's go 2026-10-19 ("yes, run Step 1"). Tools from the merged main checkout.
T=/home/arduino/Repositories/laa-npu-dev/platforms/ventuno-q-16gb/npu-dev/tools
P=$HOME/npu-dev/pkg-unpatched-ff5a2337/pkg-unpatched-ff5a2337
M=$HOME/npu-dev/b1/models/Ternary-Bonsai-2-4B-Q2_0.gguf
O=$HOME/bench-runs/npu-dev/b1/4b-load1-a3
L=$HOME/bench-runs/npu-dev/b1/4b-load1-a3-wrapper-console.txt
[ "$(cat $HOME/v0/farf/llama-server.farf)" = 0x1f ] || { echo "farf is not 0x1f"; exit 1; }
cd ~/bench-runs || exit 1
setsid nohup bash $T/npu_dev_run.sh --stage b1 --run 4b-load1-a3 --timeout 1800 --expect-dsp yes --floor-mib 1536 --stall-s 120 \
 --declared-peak-mib 1700 --declared-board-mib 2800 \
 --hash $M --hash $P/bin/llama-server --hash $P/lib/libllama-server-impl.so --hash $P/lib/libggml-htp-v75.so \
 --env GGML_HEXAGON_NHMX=1 --env LD_LIBRARY_PATH=$P/lib --env "ADSP_LIBRARY_PATH=$HOME/v0/farf;$P/lib" --env GGML_HEXAGON_DEVICES=HTP0:0 \
 --env GGML_HEXAGON_VERBOSE=1 --env GGML_SCHED_DEBUG=2 -- \
 /bin/bash $T/r2_load_probe.sh $O/probe 18090 900 -- $P/bin/llama-server -m $M -c 8192 -np 1 -fa on \
 -b 2048 -ub 512 -ngl 999 --device HTP0:0 --cache-ram 0 -lv 5 --no-webui > $L 2>&1 < /dev/null &
echo "B1c-4B Step 1 started in the background (pid $!); console: $L"
