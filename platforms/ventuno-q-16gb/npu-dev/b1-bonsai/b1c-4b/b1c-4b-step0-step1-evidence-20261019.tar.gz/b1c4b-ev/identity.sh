#!/bin/bash
# campaign identity record, as R2's identity-before/after.txt: identity.sh <out file>
I=$1
{ echo "date $(date -Iseconds)"
python3 ~/v0/pkg_identity.py check ~/v0/pkg-identity-836d57176.txt ~/v0/hexpkg/pkg-linux | tail -1
echo "retry lib $(sha256sum ~/v0/htp-retry/libggml-htp-v75.so | cut -d' ' -f1) expected aa2ae2a978d95935b763234c1a6cefe27f42c1cf98d67f041c17f13210fedde2"
echo "farf $(cat ~/v0/farf/llama-server.farf)"
echo "measure $(git -C ~/v0/measure rev-parse HEAD) dirty=$(git -C ~/v0/measure status --porcelain | wc -l)"
B=~/bench-runs/monitor/dpkg-baseline.txt
[ -s "$B" ] || { echo "dpkg-baseline MISSING $B"; exit 1; }
echo "dpkg-baseline $(sha256sum "$B" | cut -d' ' -f1) expected 7a78aa722a16ef8d9a61e47d16717be5e230c6af159582b1406ef26cd548f9ae"
echo "dpkg-now-vs-baseline-diff-lines $(diff <(dpkg-query -W -f='${Package} ${Version}\n') "$B" | grep -c '^[<>]')"
} > "$I" 2>&1; cat "$I"
