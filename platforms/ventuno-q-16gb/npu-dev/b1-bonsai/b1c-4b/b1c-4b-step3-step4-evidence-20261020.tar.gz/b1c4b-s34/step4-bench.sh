#!/bin/bash
# B1c-4B Step 4 (SPEC.txt revision 5, merged 6872d4d): llama-bench on HTP0:0 under the wrapper, after Step 3's PASS.
set -uo pipefail
T=/home/arduino/Repositories/laa-npu-dev/platforms/ventuno-q-16gb/npu-dev/tools
P=$HOME/npu-dev/pkg-unpatched-ff5a2337/pkg-unpatched-ff5a2337
M=$HOME/npu-dev/b1/models/Ternary-Bonsai-2-4B-Q2_0.gguf
FS=7acc31cde8878ed69e7db525b71c42440f49d29972de44d6c0653564a613e645
for n in llama-server llama-perplexity llama-bench; do
  echo "$FS  $HOME/npu-dev/farf/$n.farf" | sha256sum -c --quiet - || { echo "farf $n mismatch"; exit 1; }
done
L=$HOME/bench-runs/npu-dev/b1/4b-bench-wrapper-console.txt
cd ~/bench-runs || exit 1
setsid nohup bash $T/npu_dev_run.sh --stage b1 --run 4b-bench --timeout 3600 --expect-dsp yes --floor-mib 1536 --stall-s 120 \
 --declared-peak-mib 1950 --declared-board-mib 3500 \
 --hash $M --hash $P/bin/llama-bench --hash $P/lib/libllama-bench-impl.so --hash $P/lib/libllama.so.0.7.0 \
 --hash $P/lib/libggml-base.so.0.27.0 --hash $P/lib/libggml-hexagon.so.0.27.0 --hash $P/lib/libggml-htp-v75.so \
 --env GGML_HEXAGON_NHMX=1 --env LD_LIBRARY_PATH=$P/lib --env "ADSP_LIBRARY_PATH=$HOME/npu-dev/farf;$P/lib" \
 --env GGML_HEXAGON_DEVICES=HTP0:0 --env GGML_HEXAGON_VERBOSE=1 --env GGML_SCHED_DEBUG=2 -- \
 $P/bin/llama-bench -m $M -fa 1 -p 512 -n 128 -r 3 -ngl 999 -dev HTP0:0 -o md -v > $L 2>&1 < /dev/null &
echo "B1c-4B Step 4 started (pid $!); console: $L"
