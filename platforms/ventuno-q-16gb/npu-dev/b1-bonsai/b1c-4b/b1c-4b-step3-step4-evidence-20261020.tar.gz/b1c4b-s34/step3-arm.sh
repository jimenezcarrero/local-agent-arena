#!/bin/bash
# B1c-4B Step 3 (SPEC.txt revision 5, merged 6872d4d, Codex READY at 99da5d5): one T5 arm on the NPU under the wrapper.
# step3-arm.sh on|off   (3a thinking on = the template default; 3b thinking off). Runs only after Step 2's full PASS.
set -uo pipefail
ARM=$1
T=/home/arduino/Repositories/laa-npu-dev/platforms/ventuno-q-16gb/npu-dev/tools
P=$HOME/npu-dev/pkg-unpatched-ff5a2337/pkg-unpatched-ff5a2337
M=$HOME/npu-dev/b1/models/Ternary-Bonsai-2-4B-Q2_0.gguf
FS=7acc31cde8878ed69e7db525b71c42440f49d29972de44d6c0653564a613e645
for n in llama-server llama-perplexity llama-bench; do
  echo "$FS  $HOME/npu-dev/farf/$n.farf" | sha256sum -c --quiet - || { echo "farf $n mismatch"; exit 1; }
done
case $ARM in
  on)  EXTRA=();;
  off) EXTRA=(--chat-template-kwargs '{"enable_thinking":false}');;
  *) echo "arm on|off"; exit 2;;
esac
O=$HOME/bench-runs/npu-dev/b1/4b-t5-$ARM; S=$O-slots
[ -e "$S" ] && { echo "$S exists"; exit 1; }; mkdir -p "$S"
L=$HOME/bench-runs/npu-dev/b1/4b-t5-$ARM-wrapper-console.txt
cd ~/bench-runs || exit 1
setsid nohup bash $T/npu_dev_run.sh --stage b1 --run 4b-t5-$ARM --timeout 7200 --expect-dsp yes --floor-mib 1536 --stall-s 120 \
 --declared-peak-mib 1700 --declared-board-mib 2800 \
 --hash $M --hash $P/bin/llama-server --hash $P/lib/libllama-server-impl.so --hash $P/lib/libllama.so.0.7.0 \
 --hash $P/lib/libggml-base.so.0.27.0 --hash $P/lib/libggml-hexagon.so.0.27.0 --hash $P/lib/libggml-htp-v75.so \
 --env GGML_HEXAGON_NHMX=1 --env LD_LIBRARY_PATH=$P/lib --env "ADSP_LIBRARY_PATH=$HOME/npu-dev/farf;$P/lib" \
 --env GGML_HEXAGON_DEVICES=HTP0:0 --env GGML_HEXAGON_VERBOSE=1 --env GGML_SCHED_DEBUG=2 -- \
 /bin/bash $T/b1_t5_payload.sh $O/payload 18090 900 bonsai4b-npu-$ARM 900 -- \
 $P/bin/llama-server -m $M -c 8192 -np 1 --cache-ram 0 --slot-save-path $S --jinja -fa on -b 2048 -ub 512 \
 -ngl 999 --device HTP0:0 -lv 5 --no-webui "${EXTRA[@]}" > $L 2>&1 < /dev/null &
echo "B1c-4B Step 3 arm $ARM started (pid $!); console: $L"
