#!/bin/bash
# make_extract.sh <full log, gzipped> <out extract.log.gz>: the lines the B1c-4B checks read (r2_mapped_peak.py,
# r2_placement.py, d2audit.py), in log order: loader and buffer lines, scheduler split and node lines, every
# supports-op query (accepted and declined; r2_placement.py subtracts accepted ones from the zero-extent set), and the
# Hexagon mapping lines. Deterministic: zcat | grep -E with this fixed pattern | gzip -9 -n.
set -euo pipefail
zcat "$1" | grep -E "assigned to device|## SPLIT|node #|supports-op|buffer size|mapped buffer|unmapped buffer|release ref|pinned|load_tensors:" | gzip -9 -n > "$2"
