import re,sys,collections
PREFIX=re.compile(r"\d+\.\d{2}\.\d{3}\.\d{3} [IWED] ")
SPLIT=re.compile(r"^## SPLIT #(\d+): (\S+) #"); NODE=re.compile(r"^node #\s*\d+ \(\s*([A-Z_0-9]+)\): (.{20})")
L=[]; started=False
lines=PREFIX.sub("",open(sys.argv[1],errors="replace").read()).splitlines()
start=[i for i,l in enumerate(lines) if "load_tensors: layer   0 assigned" in l][-1]; lines=lines[start:]
graphs=[];cur=None;dec=[];pend=[]
for l in lines:
    if "supports-op" in l and l.rstrip().endswith("|no"):
        f=l.split("supports-op ",1)[1].split("|"); pend.append((f[0],f[1].split(" -> ")[-1].strip()[:20],f[2].split(" -> ")[-1].strip()))
    m=SPLIT.match(l)
    if m:
        if m.group(1)=="0": cur=[];graphs.append(cur);dec.append(pend);pend=[]
        cur.append([m.group(2),[]]);continue
    m=NODE.match(l)
    if m and cur is not None: cur[-1][1].append((m.group(1),m.group(2).strip()))
bad=0; s=collections.Counter()
for gi,g in enumerate(graphs,1):
    if sorted(set(op for op,_ in g[0][1]))!=['GET_ROWS']: bad+=1; print("first split", gi)
    extra=[n for si,(b,n) in enumerate(g) if b=="CPU" and si>0]
    allzero=all(any(x.strip()=="0" for x in d[2].split(":")) for d in dec[gi-1]); names={d[1] for d in dec[gi-1]}
    if extra and not (allzero and all(nm[:20] in names for n in extra for _,nm in n)): bad+=1; print("extra", gi)
    if not allzero: bad+=1; print("nonzero", gi)
    s[(len(g),len(extra),len(dec[gi-1]))]+=1
print("graphs",len(graphs),dict(s),"problems",bad)
