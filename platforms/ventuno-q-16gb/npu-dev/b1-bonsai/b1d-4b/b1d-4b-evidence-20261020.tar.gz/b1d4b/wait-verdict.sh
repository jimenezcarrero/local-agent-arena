#!/bin/bash
# wait-verdict.sh <run> <max s>: exits when the wrapper's verdict.txt exists (the wrapper console is written only at the end)
R=$HOME/bench-runs/npu-dev/b1/$1; DL=$((SECONDS + $2))
until [ -s "$R/verdict.txt" ]; do [ "$SECONDS" -gt "$DL" ] && { echo "NO VERDICT after $2 s"; exit 1; }; sleep 15; done
echo "VERDICT $1: $(cat "$R/verdict.txt")"
