#!/bin/bash
# q8_d2.sh <log or extract.gz>: B1d-4B Q8 acceptance d2 (by hand, as a script): in the last load phase, per graph, the
# FLASH_ATTN_EXT (printed cut to 10 characters, FLASH_ATTN) and SET_ROWS nodes by the split they are printed under, and the logged KV types.
f=$1; c=cat; case $f in *.gz) c=zcat;; esac
$c "$f" | sed -E 's/[0-9]+\.[0-9]{2}\.[0-9]{3}\.[0-9]{3} [IWED] //g' | awk '
  /assigned to device/ && !inl {phase++; g=0; delete fa; delete sr} {inl = /assigned to device/}
  /^## SPLIT #0:/ {g++} /^## SPLIT #/ {b=$4}
  /^node #/ && /\( *FLASH_ATTN[A-Z_]*\)/ {fa[g" "b]++}
  /^node #/ && /\( *SET_ROWS\)/ {sr[g" "b]++}
  END {for (k in fa) {split(k,x," "); fb[x[2]]++; fn[x[2]]+=fa[k]} for (k in sr) {split(k,x," "); sb[x[2]]++; sn[x[2]]+=sr[k]}
       printf "last phase %d: %d graphs\n", phase, g
       for (b in fb) printf "FLASH_ATTN_EXT under %s: %d nodes in %d graphs\n", b, fn[b], fb[b]
       for (b in sb) printf "SET_ROWS under %s: %d nodes in %d graphs\n", b, sn[b], sb[b]}'
$c "$f" | grep -E 'llama_kv_cache: size' | sed -E 's/^[0-9.]+ [ID] //' | sort -u
