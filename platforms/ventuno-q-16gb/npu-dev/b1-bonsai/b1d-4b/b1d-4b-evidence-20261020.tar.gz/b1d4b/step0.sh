#!/bin/bash
# B1d-4B Step 0 (CPU only): B1c-4B Step 0c/0d again (b1-bonsai/b1d-4b/SPEC.txt): the reference, deleted 2026-10-20 06:32 on
# the owner's instruction, regenerated at its old path and compared with its recorded sha256. No 0e. Fails closed.
set -uo pipefail
R=/home/arduino/Repositories/laa-npu-dev/platforms/ventuno-q-16gb/npu-dev
C=$HOME/npu-dev/b1/llama.cpp/build-cpu
M=$HOME/npu-dev/b1/models/Ternary-Bonsai-2-4B-Q2_0.gguf
MSHA=64a5183b44921bdb5ac4a6f5f92007821d6ebe5c66997d3c147fd214ab9433d4
W=$HOME/npu-dev/b1/b1c-4b/step0
KSHA=f2259ac78d19f170df2883f216f01d7db853d25cd693b4b7a3e0b17e87243736
SIZE=2537912260
E=$HOME/bench-runs/npu-dev/b1/4b-kv-step0-$(date +%Y%m%d-%H%M%S); mkdir -p "$E" || exit 1
log() { echo "$(date -Iseconds) $*" | tee -a "$E/status.txt"; }
die() { log "STOP: $*"; exit 1; }
git -C "$R" rev-parse HEAD > "$E/spec-commit.txt"
log "start; evidence $E; free disk $(df -h --output=avail ~ | tail -1)"

# 0a, 0b, model
(cd "$W/text" && echo "ef7edb566e3e2b2d31b29c1fdb0c89a4cc683597484c3dc2517919c615435a11  wikitext-2-raw-v1.zip" | sha256sum -c - \
  && echo "173c87a53759e0201f33e0ccf978e510c2042d7f2cb78229d9a50d79b9e7dd08  wikitext-2-raw/wiki.test.raw" | sha256sum -c -) >> "$E/status.txt" 2>&1 || die "text sha256"
echo "$KSHA  $W/tokens-bonsai4b-c1024-n10.bin" | sha256sum -c - >> "$E/status.txt" 2>&1 || die "token file sha256"
echo "$MSHA  $M" | sha256sum -c - >> "$E/status.txt" 2>&1 || die "model sha256"
(cd "$C/bin" && sha256sum llama-perplexity lib*.so*) > "$E/binaries.sha256"
cmp -s <(grep -E 'lib(ggml|ggml-base|ggml-cpu|llama|llama-common)\.so' "$E/binaries.sha256") \
       <(grep -E 'lib(ggml|ggml-base|ggml-cpu|llama|llama-common)\.so' "$HOME/bench-runs/npu-dev/b1/cpu4b-20261019-080835/binaries.sha256") \
  && log "core libraries identical to B1b-4B's" || die "core libraries differ from B1b-4B's"

# comparator from the reviewed commit
cp "$R/tools/r1_t7_compare.cpp" "$E/" && c++ -O2 -std=c++17 -o "$E/r1_t7_compare" "$E/r1_t7_compare.cpp" || die "comparator build"
sha256sum "$E/r1_t7_compare.cpp" > "$E/tools.sha256"

PPL=("$C/bin/llama-perplexity" -m "$M" -c 1024 -b 1024 --chunks 10 -t 8 -fa on)
REF=$W/cpu-ref.kld
[ -e "$REF" ] && die "$REF exists (it is never rewritten)"

# 0c
log "0c reference"
"${PPL[@]}" -ub 512 -f "$W/text/wikitext-2-raw/wiki.test.raw" --kl-divergence-base "$REF" > "$E/ppl-ref-base.log" 2>&1
log "0c exit $?"
# 0d
[ "$(stat -c %s "$REF")" = "$SIZE" ] || die "reference size $(stat -c %s "$REF") != $SIZE"
"$E/r1_t7_compare" "$REF" "$REF" "$KSHA" > "$E/ref-selfcheck.txt" 2>&1; rc=$?
cat "$E/ref-selfcheck.txt" >> "$E/status.txt"; [ $rc = 0 ] || die "self-check exit $rc"
grep -qE '^\[10\]' "$E/ppl-ref-base.log" || grep -q '\[10\]' "$E/ppl-ref-base.log" || die "base log does not show chunk 10"
grep -E "Final estimate" "$E/ppl-ref-base.log" | tee -a "$E/status.txt" | grep -qiE "nan|inf" && die "non-finite final estimate"
grep -q "Final estimate" "$E/ppl-ref-base.log" || die "no final estimate"
sha256sum "$REF" | tee "$E/cpu-ref.kld.sha256" >> "$E/status.txt"

if grep -q '^7fd9868c39deca75adb50e529ae8b005519c75eafa31df3c074aed76cece4444 ' "$E/cpu-ref.kld.sha256"; then
  log "sha256 equal to B1c-4B's recorded reference (7fd9868c...): the same reference"
else
  log "sha256 differs from B1c-4B's 7fd9868c... (recorded; the validated new file is this stage's reference)"
fi
log "done"
