#!/bin/bash
# RESUME after the 2026-10-19 03:40 power-loss reboot: the first run (cpu-20261019-010515) completed the smoke and the
# default T5 arm (20/20); this reruns only the nothink arm (from trial 1) and llama-bench. Binaries are checked against
# the first run's binaries.sha256.
# bonsai-cpu-check.sh: exploratory CPU-only check of Ternary-Bonsai-2-9B Q2_0 on the VENTUNO Q board with upstream
# llama.cpp ff5a2337 (not an NPU stage, not a campaign run). Steps: smoke generation (does it produce text, not garbage),
# the frozen T5 tool-call screen (k5-t7/t5-requests.json, the same 20 requests REF and M2 got) with the chat template's
# default and with thinking disabled, then llama-bench pp512/tg128. Evidence in ~/bench-runs/npu-dev/b1/<stamp>/.
set -uo pipefail
R=/home/arduino/Repositories/laa-npu-dev/platforms/ventuno-q-16gb/npu-dev
BIN=$HOME/npu-dev/b1/llama.cpp/build-cpu/bin
M=$HOME/npu-dev/b1/models/Ternary-Bonsai-2-9B-Q2_0.gguf
SHA=1f884aa56aacd2bbbb2e4b7abaead2b1102b74a9c75a23fc33dab916813a384d
PORT=18191
E=$HOME/bench-runs/npu-dev/b1/cpu-resume-$(date +%Y%m%d-%H%M%S); mkdir -p "$E" || exit 1
log() { echo "$(date -Iseconds) $*" | tee -a "$E/status.txt"; }
die() { log "STOP: $*"; exit 1; }
SP=
stop_server() { [ -n "$SP" ] && kill "$SP" 2>/dev/null && wait "$SP" 2>/dev/null; SP=; }
trap stop_server EXIT

log "start; model $M"
echo "$SHA  $M" | sha256sum -c - >> "$E/status.txt" 2>&1 || die "model sha256"
(cd "$BIN" && sha256sum llama-server llama-bench lib*.so* 2>/dev/null) > "$E/binaries.sha256"
cmp -s "$E/binaries.sha256" $HOME/bench-runs/npu-dev/b1/cpu-20261019-010515/binaries.sha256 && log "binaries identical to the first run" || die "binaries differ from the first run"
git -C "$HOME/npu-dev/b1/llama.cpp" rev-parse HEAD > "$E/commit.txt"
{ uname -srm; nproc; free -m; } > "$E/host.txt"

start_server() {  # <label> [extra args...]
  local l=$1; shift; mkdir -p "$E/slots-$l"
  "$BIN/llama-server" -m "$M" -c 8192 -np 1 --cache-ram 0 --slot-save-path "$E/slots-$l" --jinja -fa on \
    --host 127.0.0.1 --port $PORT --no-webui "$@" > "$E/server-$l.log" 2>&1 &
  SP=$!
  for _ in $(seq 1 300); do
    kill -0 "$SP" 2>/dev/null || die "server $l exited (server-$l.log)"
    curl -sf "http://127.0.0.1:$PORT/health" >/dev/null && { log "server $l ready"; return 0; }
    sleep 1
  done
  die "server $l not ready in 300 s"
}


# 3. T5 screen, thinking disabled through the template
start_server nothink --chat-template-kwargs '{"enable_thinking":false}'
python3 -I "$R/tools/r1_t5_screen.py" --server "http://127.0.0.1:$PORT" --requests "$R/k5-t7/t5-requests.json" \
  --out "$E/t5-nothink" --label bonsai-nothink --timeout 900 > "$E/t5-nothink.console" 2>&1; log "T5 nothink exit $?: $(tail -1 "$E/t5-nothink.console")"
stop_server

# 4. speed, CPU
"$BIN/llama-bench" -m "$M" -fa 1 -p 512 -n 128 -r 3 -o md > "$E/bench.md" 2> "$E/bench.err"; log "bench exit $?"
cat "$E/bench.md" | tee -a "$E/status.txt"
log "done; evidence $E"
